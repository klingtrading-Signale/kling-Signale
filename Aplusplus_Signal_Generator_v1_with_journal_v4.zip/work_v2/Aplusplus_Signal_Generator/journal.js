
// ajs- Journal Module (localStorage only)
(function(){
  const LS_KEY = "ajsJournalV1";
  const $ = (id)=>document.getElementById(id);

  const TICK_STEP = {
    ES:0.25, MES:0.25, NQ:0.25, MNQ:0.25,
    BTC:0.01, DOGE:0.01, SOL:0.01, SHIB:0.01, XRP:0.01
  };
  const TICK_VALUE = { ES:12.5, MES:1.25, NQ:5, MNQ:0.5, BTC:1, DOGE:1, SOL:1, SHIB:1, XRP:1 };

  // --- Hook: wrap renderSignal to capture latest signal into window.LAST_SIGNAL ---
  function hookRenderSignal(){
    if(typeof window.renderSignal !== "function") return false;
    if(window.__AJS_RENDER_HOOKED__) return true;
    const orig = window.renderSignal;
    window.renderSignal = function(res, market){
      try{
        window.LAST_SIGNAL = {
          date: new Date().toISOString().slice(0,10),
          market: market,
          side: res.side,
          orderType: res.orderType || "Limit",
          entry: Number(res.entry),
          sl: Number(res.sl),
          tps: Array.isArray(res.tps) ? res.tps.map(Number) : [],
          crv: Number(res.crv),
          tp1Prob: Number(res.tp1Prob || 0)
        };
        const addBtn = document.getElementById('ajsJournalAddBtn');
        if(addBtn) addBtn.removeAttribute('disabled');
      }catch(e){}
      return orig.apply(this, arguments);
    };
    window.__AJS_RENDER_HOOKED__ = true;
    return true;
  }

  // --- Fallback: Observe #signalArea and parse DOM to capture latest signal ---
  function parseFromCopyBox(text){
    if(!text) return null;
    try{
      // Example format:
      // <ampel> <rating> – <market> (<BUY|SELL> <LIMIT|STOP>)
      // Entry: <num>
      // SL: <num>
      // TPs: n1, n2, n3
      // CRV: x.xx | Tagestrend: ... | TP1-Wahrscheinlichkeit: 75%
      const header = text.split("\n")[0] || "";
      const mHead = header.match(/–\s*([A-Z]+)\s*\(\s*(BUY|SELL)\s+(LIMIT|STOP)\s*\)/i);
      const market = mHead ? mHead[1].toUpperCase() : (document.getElementById("market")?.value || "");
      const side = mHead ? (mHead[2].toLowerCase()) : "";
      const orderType = mHead ? (mHead[3].charAt(0)+mHead[3].slice(1).toLowerCase()) : "Limit";

      const mEntry = text.match(/Entry:\s*([0-9]+(?:\.[0-9]+)?)/i);
      const mSL = text.match(/SL:\s*([0-9]+(?:\.[0-9]+)?)/i);
      const mTPs = text.match(/TPs:\s*([0-9\.\,\s]+)/i);
      const mCRV = text.match(/CRV:\s*([0-9]+(?:\.[0-9]+)?)/i);
      const mTP1 = text.match(/TP1-?Wahrscheinlichkeit:\s*([0-9]+)\s*%/i);

      const entry = mEntry ? Number(mEntry[1]) : null;
      const sl = mSL ? Number(mSL[1]) : null;
      const tps = mTPs ? mTPs[1].split(",").map(s=>Number(s.trim())).filter(n=>!Number.isNaN(n)) : [];
      const crv = mCRV ? Number(mCRV[1]) : null;
      const tp1Prob = mTP1 ? (Number(mTP1[1])/100) : 0;

      if(entry!=null && sl!=null && tps.length){
        return {market, side, orderType, entry, sl, tps, crv, tp1Prob};
      }
      return null;
    }catch(e){ return null; }
  }

  function startSignalObserver(){
    const area = document.getElementById("signalArea");
    if(!area) return;

    const enable = ()=>{ const b=document.getElementById("ajsJournalAddBtn"); if(b) b.removeAttribute("disabled"); };

    const handle = ()=>{
      const copy = document.getElementById("copyBox");
      const text = copy ? copy.textContent : "";
      const parsed = parseFromCopyBox(text);
      if(parsed){
        window.LAST_SIGNAL = Object.assign({ date: new Date().toISOString().slice(0,10) }, parsed);
        enable();
      }
    };

    // Initial check + mutation observer
    handle();
    const mo = new MutationObserver(()=>handle());
    mo.observe(area, {childList:true, subtree:true, characterData:true});
    // periodic fallback
    let tries=0; const t=setInterval(()=>{ handle(); if(++tries>30) clearInterval(t); }, 500);
  }



  function load(){ try{ return JSON.parse(localStorage.getItem(LS_KEY)||"[]"); }catch(e){ return [];} }
  function persist(data){ localStorage.setItem(LS_KEY, JSON.stringify(data)); }
  function ensureIds(rows){
    let changed=false;
    rows.forEach(r=>{
      if(!r.id){
        // generate deterministic-ish id using core fields + time
        const core = [r.date,r.market,r.side,r.orderType,r.entry,r.sl,(r.tps||[]).join("|")].join("||");
        r.id = (Date.now().toString(36)) + "-" + (Math.random().toString(36).slice(2,8));
        r.createdAt = r.createdAt || new Date().toISOString();
        r.updatedAt = r.updatedAt || r.createdAt;
        changed=true;
      }
    });
    if(changed) persist(rows);
    return rows;
  }
        
  function save(){} // deprecated

  function fmtNum(n){ return (n===null||n===undefined||Number.isNaN(n))?"":String(n); }
  function toTicks(market, priceDiff){
    const step = TICK_STEP[market] || 0.01;
    return Math.round(priceDiff / step);
  }
  function pnlUSD(market, ticks, contracts){
    const tv = TICK_VALUE[market] || 1;
    return ticks * tv * (contracts||1);
  }

  function computePnL(entry, exit, side, market, contracts){
    if(entry===null || exit===null) return {ticks:null, usd:null};
    const diff = (side==="long") ? (exit - entry) : (entry - exit);
    const ticks = toTicks(market, diff);
    const usd = pnlUSD(market, ticks, contracts);
    return {ticks, usd};
  }

  function render(){
    const rows = ensureIds(load());
    const fM = $("ajs-filter-market")?.value || "ALL";
    const fS = $("ajs-filter-status")?.value || "ALL";

    const tbody = $("ajs-journal-table").querySelector("tbody");
    tbody.innerHTML = "";

    const filtered = rows.filter(r => (fM==="ALL"||r.market===fM) && (fS==="ALL"||r.status===fS));

    filtered.forEach((r, idx)=>{
      const tr = document.createElement("tr");
      const tpsStr = (r.tps||[]).filter(x=>x!==null && x!==undefined && x!=="").join(", ");
      tr.innerHTML = `
        <td>${fmtNum(r.date)}</td>
        <td>${fmtNum(r.market)}</td>
        <td>${fmtNum(r.side)}</td>
        <td>${fmtNum(r.orderType)}</td>
        <td>${fmtNum(r.entry)}</td>
        <td>${fmtNum(r.sl)}</td>
        <td>${tpsStr}</td>
        <td>${fmtNum(r.crv)}</td>
        <td>${fmtNum(r.tp1Prob)}</td>
        <td>${fmtNum(r.contracts)}</td>
        <td><span class="ajs-pill">${fmtNum(r.status)}</span></td>
        <td>${fmtNum(r.pnlTicks)}</td>
        <td>${fmtNum(r.pnlUSD)}</td>
        <td>${(r.note||"")}</td>
        <td class="ajs-actions">
          <button data-act="TP1" data-id="${r.id}">TP1</button>
          <button data-act="TP2" data-id="${r.id}">TP2</button>
          <button data-act="TP3" data-id="${r.id}">TP3</button>
          <button data-act="SL" data-id="${r.id}">SL</button>
          <button data-act="MANUAL" data-id="${r.id}">Manuell</button>
          <button data-act="DEL" data-id="${r.id}">Löschen</button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    renderStats(rows);
  }

  function renderStats(allRows){
    const closedStatuses = new Set(["TP1","TP2","TP3","SL","MANUAL"]);
    const closed = allRows.filter(r=>closedStatuses.has(r.status));
    const wins = closed.filter(r => ["TP1","TP2","TP3"].includes(r.status));
    const sumTicks = closed.reduce((a,b)=>a + (Number(b.pnlTicks)||0), 0);
    const sumUSD = closed.reduce((a,b)=>a + (Number(b.pnlUSD)||0), 0);

    const statsEl = $("ajs-stats");
    const hitRate = closed.length ? Math.round((wins.length/closed.length)*100) : 0;
    const text = [
      `Trefferquote: ${hitRate}%`,
      `Summe Ticks: ${sumTicks}`,
      `Summe USD: ${sumUSD.toFixed(2)}`,
      `Anzahl Trades: ${allRows.length}`,
      `Anzahl geschlossen: ${closed.length}`
    ].join(" · ");
    statsEl.textContent = text;
  }

  function updateStatusById(id, newStatus){
    const data = ensureIds(load());
    const i = data.findIndex(x=>x.id===id); const r = data[i];
    if(!r) return;

    let exitPrice = null;
    if(newStatus==="TP1"||newStatus==="TP2"||newStatus==="TP3"){
      const tpIdx = ({TP1:0,TP2:1,TP3:2})[newStatus];
      exitPrice = (r.tps && r.tps[tpIdx] != null) ? Number(r.tps[tpIdx]) : null;
      if(exitPrice==null){
        const manual = prompt(`${newStatus}: Kein TP gespeichert. Exit-Preis eingeben:`);
        exitPrice = manual ? Number(manual) : null;
      }
    } else if(newStatus==="SL"){
      exitPrice = Number(r.sl);
    } else if(newStatus==="MANUAL"){
      const manual = prompt("Manueller Exit: Exit-Preis eingeben:");
      exitPrice = manual ? Number(manual) : null;
    }

    const {ticks, usd} = computePnL(Number(r.entry), exitPrice, r.side, r.market, Number(r.contracts||1));
    r.status = newStatus; r.updatedAt = new Date().toISOString();
    r.pnlTicks = (ticks!=null)?ticks:null;
    r.pnlUSD = (usd!=null)?Number(usd.toFixed(2)):null;

    persist(data);
    render();
  }

  function removeRowById(id){
    const data = ensureIds(load());
    const i = data.findIndex(x=>x.id===id); if(i>=0) data.splice(i,1);
    persist(data);
    render();
  }

  function addFromLastSignal(){
    if(!window.LAST_SIGNAL){
      alert("Kein Signal gefunden. Generiere zuerst ein Handelssignal.");
      return;
    }
    const contractsStr = prompt("Kontrakte (Anzahl, Zahl):", "1");
    const contracts = contractsStr ? Number(contractsStr) : 1;
    const note = prompt("Notiz (optional):", "") || "";

    const s = window.LAST_SIGNAL;
    const entry = Number(s.entry);
    const sl = Number(s.sl);
    const tps = Array.isArray(s.tps) ? s.tps.filter(x=>x!=null).map(Number) : [];

    const row = {
      id: (Date.now().toString(36)) + '-' + (Math.random().toString(36).slice(2,8)),
      date: s.date || new Date().toISOString().slice(0,10),
      market: s.market,
      side: s.side,
      orderType: s.orderType,
      entry, sl, tps,
      crv: Number(s.crv),
      tp1Prob: Number(s.tp1Prob),
      contracts: Number(contracts),
      status: "OPEN",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      pnlTicks: null,
      pnlUSD: null,
      note
    };
    const data = ensureIds(load());
    data.unshift(row);
    persist(data);
    render();
  }

  
  function toJSON(rows){
    return JSON.stringify({schema:1, entries: rows}, null, 2);
  }

  function mergeAndDedupe(existing, incoming){
    const key = (r)=>[r.date,r.market,r.side,r.orderType,r.entry,r.sl,(r.tps||[]).join("|")].join("||");
    const map = new Map();
    existing.forEach(r=>map.set(key(r), r));
    incoming.forEach(r=>{
      const k = key(r);
      if(!map.has(k)){
        map.set(k, r);
      }else{
        // If duplicate exists, prefer one that has PnL/status filled
        const a = map.get(k);
        const hasA = (a && (a.status!=="OPEN" || a.pnlUSD!=null));
        const hasB = (r && (r.status!=="OPEN" || r.pnlUSD!=null));
        if(!hasA && hasB) map.set(k, r);
      }
    });
    return Array.from(map.values());
  }

  function toCSV(rows){

    const headers = ["date","market","side","orderType","entry","sl","tps","crv","tp1Prob","contracts","status","pnlTicks","pnlUSD","note"];
    const lines = [headers.join(",")];
    rows.forEach(r=>{
      const tps = (r.tps||[]).join("|");
      const vals = [
        r.date, r.market, r.side, r.orderType, r.entry, r.sl, tps, r.crv, r.tp1Prob, r.contracts, r.status, r.pnlTicks, r.pnlUSD, JSON.stringify(r.note||"")
      ];
      lines.push(vals.map(v => (v===undefined||v===null)?"":String(v)).join(","));
    });
    return lines.join("\n");
  }

  function wireEvents(){
    const table = $("ajs-journal-table");
    table.addEventListener("click", (e)=>{
      const btn = e.target.closest("button");
      if(!btn) return;
      const act = btn.getAttribute("data-act");
      const id = btn.getAttribute("data-id");
      if(act==="DEL"){ removeRowById(id); return; }
      updateStatusById(id, act);
    });

    $("ajs-filter-market").addEventListener("change", render);
    $("ajs-filter-status").addEventListener("change", render);


    $("ajs-export-csv").addEventListener("click", ()=>{

      const rows = ensureIds(load());
      const csv = toCSV(rows);
      const blob = new Blob([csv],{type:"text/csv;charset=utf-8"});
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = "journal.csv";
      document.body.appendChild(a); a.click(); a.remove();
      URL.revokeObjectURL(url);
    });

    $("ajs-export-json").addEventListener("click", ()=>{
      const rows = ensureIds(load());
      const blob = new Blob([toJSON(rows)],{type:"application/json;charset=utf-8"});
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = "journal-backup.json";
      document.body.appendChild(a); a.click(); a.remove();
      URL.revokeObjectURL(url);
    });

    $("ajs-import-json-btn").addEventListener("click", ()=> $("ajs-import-json").click());
    $("ajs-import-json").addEventListener("change", async (e)=>{
      const f = e.target.files && e.target.files[0]; if(!f) return;
      const text = await f.text();
      try{
        const obj = JSON.parse(text);
        const incoming = Array.isArray(obj) ? obj : (Array.isArray(obj.entries) ? obj.entries : []);
        if(!incoming.length){ alert("Keine Einträge in der JSON gefunden."); return; }
        const merged = mergeAndDedupe(load(), incoming);
        save(merged); render(); alert(`Import erfolgreich: +${merged.length} gesamt.`);
      }catch(err){ alert("Import fehlgeschlagen: " + err.message); }
      e.target.value = "";
    });

    $("ajs-clear-journal").addEventListener("click", ()=>{
      if(confirm("Journal wirklich leeren? (Nur lokal in diesem Browser)")){
        save([]); render();
      }
    });

    const addBtn = $("ajsJournalAddBtn");
    if(addBtn){
      addBtn.addEventListener("click", addFromLastSignal);
      // Enable button once LAST_SIGNAL appears
      const enableIfSignal = ()=>{
        if(window.LAST_SIGNAL){ addBtn.removeAttribute("disabled"); }
      };
      enableIfSignal();
      const origDef = Object.getOwnPropertyDescriptor(window, "LAST_SIGNAL");
      try{
        Object.defineProperty(window, "LAST_SIGNAL", {
          set(v){ if(origDef && origDef.set) origDef.set(v); else this.___LAST_SIGNAL=v; addBtn.removeAttribute("disabled"); },
          get(){ return (origDef && origDef.get)? origDef.get() : this.___LAST_SIGNAL; }
        });
      }catch(e){
        // fallback: poll
        setInterval(enableIfSignal, 1000);
      }
    }
  }

  document.addEventListener("DOMContentLoaded", ()=>{
    startSignalObserver();
    hookRenderSignal();
    let tries=0; const t=setInterval(()=>{ if(hookRenderSignal()||tries++>20) clearInterval(t); }, 200);
    wireEvents();
    render();
  });
})();
