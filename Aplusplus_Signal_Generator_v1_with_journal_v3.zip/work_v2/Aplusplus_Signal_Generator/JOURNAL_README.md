# Journal Modul (A++ Webtool)

**Dateien hinzugefügt**: `journal.css`, `journal.js` und Journal-Block in `index.html` (Section mit id `ajs-journal-section`).

## Einbaupunkte
- `index.html`:
  - `<link rel="stylesheet" href="./journal.css">` im `<head>`
  - `<script src="./journal.js"></script>` vor `</body>`
  - Button **„Zum Journal hinzufügen“** (`id="ajsJournalAddBtn"`) unter **Handelssignal**
  - Journal-Section (`id="ajs-journal-section"`) am Ende des Hauptinhalts
- Bestehende Logik/Styles wurden nicht überschrieben.

## Hook
Die App setzt nicht automatisch `window.LAST_SIGNAL`. Daher hakt sich `journal.js` minimalinvasiv in die vorhandene `renderSignal(res, market)`-Funktion ein (Wrapper) und schreibt dabei automatisch `window.LAST_SIGNAL`.

Du kannst weiterhin manuell setzen:
```js
window.LAST_SIGNAL = { date, market, side, orderType, entry, sl, tps:[tp1,tp2?,tp3?], crv, tp1Prob };
document.getElementById('ajsJournalAddBtn')?.removeAttribute('disabled');
```

## Datenhaltung
- Speicherung im `localStorage` (`ajsJournalV1`) pro Browser/Nutzer.
- Felder: `date, market, side, orderType, entry, sl, tps[], crv, tp1Prob, contracts, status (OPEN|TP1|TP2|TP3|SL|MANUAL), pnlTicks, pnlUSD, note`.

## Tick-Logik
- Tick-Schritt: ES/MES/NQ/MNQ = 0.25; Krypto = 0.01.
- Tickwerte: ES=12.5, MES=1.25, NQ=5, MNQ=0.5, Krypto=1 (Platzhalter).


## Persistenz & Backups
- Daten werden im `localStorage` gespeichert und bleiben über Sessions erhalten.
- **Empfehlung:** Nutze regelmäßig **JSON Export** (wieder importierbar) als Backup – z. B. monatlich.
- CSV-Export dient zur Auswertung, JSON-Export/Import zum Archivieren und Wiederherstellen.
