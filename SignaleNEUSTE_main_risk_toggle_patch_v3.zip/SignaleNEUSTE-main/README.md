# A++ Signal Generator (Prototype v1.0)
- ES/MES/NQ/MNQ & BTC/DOGE/SOL/SHIB/XRP
- Option-Chain PDF Upload (ES/MES) via pdf.js CDN
- NQ/MNQ: manuelle (Strike/OI) Eingabe
- A++-Filter (Trend, VTH/VTL), CRV-Min-Filter, bis zu 3 TPs
- Reines Frontend (Static); lokal über `index.html` oder via Vercel (kein Build nötig)
