# Journal-Modul – Plug & Play
(…siehe Anleitung im Chat oben – identisch)